from game import Tictactoe, Player

game = Tictactoe()
game.play()