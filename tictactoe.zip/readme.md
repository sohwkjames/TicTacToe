Requirements: Python3

Instructions:

-Unzip the contents of the file.

-Open terminal and navigate to the location you unzipped

-Run "python3 main.py" in the terminal

-Follow the instructions and enjoy the game!

Code by: James Soh